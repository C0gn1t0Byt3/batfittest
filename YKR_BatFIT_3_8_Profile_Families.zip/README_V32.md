# YKR BatFIT v3.2 – Blade Shape CAD

## Changes from v3.1
- Added editable longitudinal blade bow (mm), face camber (mm), toe taper/rounding parameter (mm) and shoulder transition length (mm).
- These parameters are included in the generated OpenSCAD solid model.
- Five-station-style preview and existing fitting, impact mapping, comparisons and AI integrations are preserved.
- Header and designer version updated to v3.2.
- Exported model was smoke-tested by rendering the default SCAD into a watertight STL using OpenSCAD.

## Design limitations
- The toe_round_mm parameter controls a smooth width taper near the toe; it is **not** a full 3D fillet.
- The shoulders are represented by a tapered width region, not a manufacturable splice interface.
- Bow and camber are present in exported geometry, but **not in the simple in-browser 2D drawing**.
- Weight and balance estimates still use a simplified symmetric blade without changes in volume caused by the bow/face-camber model. These are preliminary only and must be weighed and balanced physically.
- No handle splice, real grain/material distribution, blade face pressing, machining fixtures, datum features, tolerance annotations or CAM toolpaths.
- SCAD is editable parametric geometry and can be exported to mesh STL from OpenSCAD; it is not STEP or CNC G-code.

## Update
1. Back up the existing `data/` directory and `.env`.
2. Extract v3.2 over the application code, preserving those two items.
3. Run `docker compose up -d --build` from the application directory.
4. Visit http://localhost:3001 and open a fitting -> Custom Bat Designer.
