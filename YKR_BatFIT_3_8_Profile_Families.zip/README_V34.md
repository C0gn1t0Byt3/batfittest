# YKR BatFIT v3.4 — rear profile and deployment

Changes:
- Rear blade uses a broad central spine and configurable **spine-to-flank blend**. Smooth trough position for concaving is independently adjustable.
- OpenSCAD, STL and interactive preview are driven by the same back-surface profile equations.
- Added **Cross-section CSV** export with modelled rear-surface heights at sampled toe stations (not toolpaths).
- v3.4 version in header and designer.
- Added optional Render `render.yaml` with persistent disk and a health route; Render Starter/Persistent Disk incurs charges. A Render web service has a public URL: don't deploy with the development password or private player data without adequate authentication.

For local Docker: preserve `data/` and `.env`, then `docker compose up -d --build`. Access http://localhost:3001.

CNC limitations: flat face, straight-sided blade blank, simplified longitudinal spine. No machined toe, shoulders, handle, fixturing, CAM/G-code or STEP export. Verify actual willow density and inspect the mesh before manufacturing. Cross-section CSV describes geometric samples, not tolerances or a manufacturing drawing.
