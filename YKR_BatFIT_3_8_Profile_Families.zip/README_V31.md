# BatFIT v3.1 – Parametric CAD starter

## What's new
- Replaces blocked five-station entry workflow with prefilled adjustable model.
- Live back-view/depth plotting and immediate mass/balance estimates.
- Generates a real editable **OpenSCAD .scad** procedural 3D CAD model for OpenSCAD / STL export.
- Save configurations; export JSON parameters.

## CAD/CNC workflow
1. Update bat dimensions, check assumptions and export `.scad`.
2. Open in OpenSCAD, press F6, inspect solid and export STL.
3. Import into CAD/CAM (e.g. FreeCAD or Fusion) and reconstruct/validate surfaces if needed. STL is a faceted solid; STEP export is not provided directly.
4. Add manufacturing requirements: bow, shoulder, splice, face finish, toe shape, timber allowance, datum and fixturing.
5. Generate cutter-specific toolpaths in CAM; simulate and inspect before cutting.

## Important model limitations
Approximate symmetrical flat-face bat, crowned back and simple cylindrical handle; not a production bat profile. Estimated total mass is calculated from assumed wood/handle density and does not enforce target mass. Balance is approximate. No structural verification, legality guarantee or G-code. Keep backups of `data/` and `.env` before update.

Run `docker compose up -d --build` and open your existing port 3001.
