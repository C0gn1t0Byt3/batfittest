# YKR BatFIT v3.8

Profile-family continuous geometry engine replaces nine editable longitudinal stations. The designer supports Mid, High, Low, Extra Low, Full Profile, Full Spine, Extended Spine, Duckbill and Concave profiles, with three instant comparison buttons. The backend calculates blade-only volume, mass, centre of mass and toe-axis longitudinal inertia. Browser mesh, STL and OpenSCAD mesh handoff use identical geometry. Existing STL scan overlay, fitting history and Gemini analysis are retained.

The profile families are provisional design templates, not validated performance recommendations or verified copies of commercial bat geometries. Peak location is a design control and not a sweet-spot measurement. OpenSCAD output is mesh-backed rather than an editable CAD feature tree. No new player-style questionnaire or automatic fitting optimiser is in this release.

To deploy: back up data and .env, replace app source, run `docker compose up -d --build`; access on your configured LAN/localhost port.
