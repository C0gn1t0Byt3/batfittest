# YKR BatFIT 2.5 — decision-focused fitting

Upgrade over version 2.4: keep your existing `data/` directory and `.env` file. Extract source over existing files and run `docker compose up -d --build`. Access `http://localhost:3001`.

### What changed
- Original PNG logos are tightly cropped to eliminate excessive transparent padding.
- Short, comparison-led fitting decision: provisional reference bat, recorded weight/balance, contact region, one next test.
- Measured data / numerical rules are authoritative; Gemini (optional) contributes only a short observation.
- Objective and session notes can be edited, saved and included as interpretative context. Notes do not change engineering calculations or targets.
- Core/optional input labels, new PNG YKR logo, fixed legacy-history missing-template error and removed broken history navigation.
- No schema migration needed; existing notes and goal columns are reused.

### Input relevance
- Mass and balance affect first mass moment and candidate targets. Bat length checks physical plausibility and comparison geometry.
- Swing speed and multi-impact map are core comparative outcome variables.
- Edge/spine/handle and subjective ratings inform future designs but currently do not change computed targets.
- Single manual impact height/offset is optional when mapped impacts are present.
- Notes are context, not verified measurement; AI cannot use notes to invent target values.

### Caution
This is a prototype; measured values and test comparability must be verified by the operator. No manufacturing approval or validated sweet-spot prediction is provided.


See README_V28.md for geometry lab instructions.

## v3.5
Fitter-linked initial blade geometry, browser-side STL overlay, preview fallback, and focused CNC screen. STL scan overlay requires manual orientation and calibration; does not generate a manufacturing recommendation from scan alone.
