# YKR BatFIT v3.5.1 — 3D viewer hotfix

Fixes the page-breaking JavaScript syntax error in the cross-section CSV export code. The same error stopped the 3D view and STL import handlers from initialising in v3.5.

Changes:
- Corrected the escaped newline in the rendered designer JavaScript.
- Initialise the renderer as soon as the DOM is ready and provide status messages.
- Improved viewer startup and handling when the server calculation fails.
- STL import automatically scales and rotates bounding axes for **visual overlay only**; this is not metrology-grade registration. Very large scans may render slowly; overlay drawing is decimated.
- Version label v3.5.1 and export filenames updated.

Testing:
- The generated HTML's embedded JavaScript passes `node --check`.
- Headless Chromium confirms blade rendering and an STL upload handler working, with no browser JS exceptions.
- The backend parametric geometry calculation runs successfully with example dimensions.
- Live authenticated server/database integration wasn't exercised.

Installation: Back up `data/` and `.env` first. Replace source from the archive while retaining those files; run `docker compose up -d --build`. If the browser caches a previous page, hard refresh.
