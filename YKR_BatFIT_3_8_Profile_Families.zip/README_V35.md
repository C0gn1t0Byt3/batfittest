# YKR BatFIT v3.5

- 3D blade preview falls back to a local mesh if the server geometry endpoint fails, with visible error.
- STL scan import (binary and ASCII), visual wireframe overlay, reported dimensions and manual alignment caveat.
- Fitting reference shown at the top of the designer. Defaults remain assumed until measured.
- Hand-finishing block removed.
- Existing fitting and CNC exports retained.

This is an engineering prototype: the scan is not auto-registered to the blade, and the model does not derive a validated optimal shape. Verify geometry before CAD/CAM work.
