# YKR BatFIT v2.8 – Geometry Lab

## What v2.7's result actually means
Bat #2 had the most favourable recorded speed/contact-spread combination under the selected goal. It does **not** prove an optimal bat design. The spine peak was missing (`—`), so v2.7 could not make any geometric comparison, and its proposed designs retained the same mass and balance.

## New in v2.8
- Header displays **BatFIT v2.8**.
- **Open geometry lab** button on each fitting session.
- Enter a measured baseline (mass, handle-end balance, total length, blade dimensions) and proposed local reduction in spine height.
- Calculate estimated removed material, resulting total mass and handle-end balance using a deterministic volume/mass model.
- Save multiple named modelling scenarios in SQLite, separate from actual measurements and approved manufacturing specifications.
- No extra containers, API keys, n8n or AI calls required.

## Geometry assumptions and limits
- A symmetric triangular cross-section for raised spine above edge thickness, consistent blade width, constant **estimated** willow density, and a triangular longitudinal shaping zone centred on spine-peak height.
- The model calculates a mass removed at each station and subtracts its first moment from the actual measured bat total. It does *not* require estimating the whole bat from its profile.
- It does **not** estimate bat sweet spot, coefficient of restitution, blade failure limits, baseline swing moment of inertia or actual three-dimensional shape.
- The model is suited to comparing approximate shaping changes, not to making cutting or structural decisions. No additive shaping supported. Result must be checked by weighing after shaping.

## Update
1. Back up your existing `data/` folder and `.env` file.
2. Extract this release over the existing source while keeping `data/` and `.env`.
3. Run `docker compose up -d --build`.
4. Visit `http://localhost:3001`, open a fitting and select **Open geometry lab (v2.8)**.

Tested: Node.js syntax for service/routes and representative geometric scenarios; no full browser/Docker end-to-end test completed.
