(() => {
 const svg=document.querySelector('#impact-face');if(!svg)return;
 const saved=JSON.parse(document.querySelector('#impact-data').textContent);const draft=[];
 const groupSaved=document.querySelector('#saved-impact-points'),groupDraft=document.querySelector('#draft-impact-points');
 const lengthEl=document.querySelector('#impact-blade-length'),msg=document.querySelector('#impact-message');
 const NS='http://www.w3.org/2000/svg';
 function coords(p){const length=Number(lengthEl.value)||550;return {x:110+p.x_mm*56/54,y:345-p.y_mm*260/length}}
 function dot(g,p,color){const q=coords(p);const circle=document.createElementNS(NS,'circle');circle.setAttribute('cx',q.x);circle.setAttribute('cy',q.y);circle.setAttribute('r','5');circle.setAttribute('fill',color);circle.setAttribute('stroke','#fff');circle.setAttribute('stroke-width','1.1');g.append(circle)}
 function render(){groupSaved.replaceChildren();groupDraft.replaceChildren();saved.forEach(p=>dot(groupSaved,p,'#232323'));draft.forEach(p=>dot(groupDraft,p,'#006680'));document.querySelector('#impact-count').textContent=saved.length+' saved + '+draft.length+' pending'}
 svg.addEventListener('click',ev=>{const pt=svg.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;const m=svg.getScreenCTM();if(!m)return;const s=pt.matrixTransform(m.inverse());if(s.x<56||s.x>164||s.y<85||s.y>345)return;const length=Number(lengthEl.value);if(!Number.isFinite(length)||length<250||length>650){msg.textContent='Enter a valid blade length first';return}draft.push({x_mm:Math.round((s.x-110)*54/56*10)/10,y_mm:Math.round((345-s.y)*length/260*10)/10,shot_type:document.querySelector('#impact-shot').value});msg.textContent='';render()});
 window.addEventListener('ykr-photo-impacts',ev=>{const points=ev.detail;if(!Array.isArray(points))return;draft.push(...points.slice(0,100));msg.textContent=points.length+' photo marks imported. Review blue points and save.';render();document.querySelector('#impact-face').scrollIntoView({behavior:'smooth',block:'center'});});
 document.querySelector('#impact-undo').addEventListener('click',()=>{draft.pop();render()});lengthEl.addEventListener('change',render);
 document.querySelector('#impact-save').addEventListener('click',async()=>{if(!draft.length){msg.textContent='Add one or more contacts first';return}const btn=document.querySelector('#impact-save');btn.disabled=true;try{const res=await fetch('/workspace/sessions/'+window.YKR_IMPACT_SESSION+'/impacts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({points:draft})});if(!res.ok)throw Error((await res.json()).error||'Unable to save impacts');saved.push(...draft);draft.length=0;msg.textContent='Contacts saved successfully';render()}catch(e){msg.textContent=e.message}finally{btn.disabled=false}});
 render();
})();
