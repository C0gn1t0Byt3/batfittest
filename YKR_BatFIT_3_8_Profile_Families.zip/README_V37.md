# YKR BatFIT v3.7 — peaked spine and practical fitting

- Rear cross-section now uses a central peaked spine rather than a flat crown. Concaving defaults to zero; light concaving is an optional CNC variant.
- Nine longitudinal spine depth stations remain editable in Advanced controls. Preview and exported OpenSCAD use the same transverse shape equations.
- Fitting-based design experiments provide full-back, light-concave and lower-spine alternatives. These are comparisons of geometric effects, **not** evidence of optimum rebound/sweet spot.
- Blade mass and inertia about the toe are model estimates requiring assumed willow density, not whole-bat MOI.
- Pendulum timing entry removed from standard fitting screen; existing data and legacy endpoint remain intact. Fitters continue comparing swing speed, impact spread, player preference, mass and balance.
- No extra Docker configuration. Retain data folder and .env; docker compose up -d --build.
