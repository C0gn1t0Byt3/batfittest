# YKR BatFIT v3.0 — fitter-focused design and CAD handoff

## Updates
- Fitting report: best tested bat and required fitter action first; detailed geometry / design text expandable.
- Designer: individual field validation explains missing or impossible dimensions (instead of generic range failure).
- CNC handoff: export station cross-sections to CSV, and CAD-neutral JSON with baseline, proposed profile and mass/balance estimates.
- Version v3.0 appears in header.

## CNC warning
Five longitudinal sections are not sufficient to generate a machinable 3D bat model, and this package does NOT provide G-code or verified tool paths. Export data is a DRAFT CAD/CAM handoff. A full 3D scan or sufficient transverse sections, reference datums, manufacturing allowances, fixture coordinates, cutter strategy and machine-specific postprocessing are required for CNC production.

## Upgrade
Preserve `data/` and `.env`. Extract package over current app and run `docker compose up -d --build`. Existing port remains 3001.
