# BatFIT v3.3 – CNC Blade-only Designer

## Workflow

1. Open fitting session → CNC Blade Designer.
2. Enter blade length and full-width dimensions, back edge thickness, maximum depth and its position above toe, ridge width and concaving depth.
3. Drag the 3D preview to rotate. Scroll to zoom. Toggle wireframe to inspect the mesh.
4. Export OpenSCAD (.scad) for parametric source or STL for CAM import.
5. In CAD/CAM, check geometry, machining stock, secure fixturing, cutters, zero datums and toolpaths. Complete face camber, shoulder/toe rounding and handle fitting by hand.

## Changed from v3.2

- Uniform blade width, with NO toe taper and NO shoulder taper.
- Removed handle shape, bow and face camber controls, and removed those features from exported CNC geometry.
- Machined geometry consists of flat blade front and editable longitudinal back spine/concaving.
- Interactive local browser 3D preview (drag rotate, zoom, wireframe) from same mesh as STL.
- Parametric OpenSCAD export still available, now blade-only.
- Model mass is blade-only; it does not predict complete bat mass.
- Header displays v3.3.

## Notes

- Exported shapes are geometry for CAD/CAM preparation, NOT G-code. Inspect generated shapes and verify machine limits before cutting.
- Flat/square toe and shoulder ends are intentional stock/hand-finishing geometry.
- No splice, handle, face camber, bow or toe/shoulder finishing is modelled.
- Actual willow density, weight and final balance require measurement.
- Existing fitting sessions and data folder are preserved.

## Update

Back up data and .env, replace the app source with v3.3, run `docker compose up -d --build`, then visit http://localhost:3001.
