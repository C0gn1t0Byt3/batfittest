# YKR BatFIT v2.9 – Custom Bat Designer

## Upgrade
Back up your current `data/` folder and `.env` file. Extract this release over your current source, preserving your existing data and settings. From the application directory, run `docker compose up -d --build`. Open http://localhost:3001. No new containers or API keys are required.

## New workflow
Open a fitting session → **Open custom bat designer (v2.9)**. Select an objective (reduce weight / shift balance / compare profile / reproduce bat). The system imports available measured baseline readings. Expand reference measurements to fill gaps, then enter five blade-station width/edge/depth readings. Click Calculate design to view the proposed mass reduction, balance shift and reference/modified centre-depth curves. Save to the existing geometry_scenarios table.

## Measurement/engineering limitations
This is an approximate engineering comparison, not a CNC template or physical performance predictor. The model uses five linearly interpolated blade cross-sections, symmetric triangular crown approximation, and estimated homogeneous willow density. Only a tapered removal from the rear crown is modelled; adding material, widening the blade and changing its handle are not represented. It cannot establish an optimum sweet spot, safe remaining thickness, actual rebound, or total swing moment of inertia. Targets outside the allowed 12 mm modelled shave depth (or available crown thickness) are reported as infeasible instead of extrapolated. Save scenarios as exploratory designs only; verify physical dimensions and strength before working on a bat.

## Features retained
Impact photo/manual mapping, player and bat records, trial comparison, fitting decisions, draft designs, and optional Gemini AI analysis. Original v2.8 manual geometry API remains available internally for backward compatibility.

## Docker
Existing `compose.yml` continues to expose port 3001. Do not publish your development environment to the internet. Preserve `data/` and `.env` on upgrade.
