# YKR BatFIT v3.6 – Nine-station spine / MOI fitting

## Scope
- Nine editable centre-depth stations across the blade from toe (0) to shoulder (blade length).
- Smooth interpolation and rounded crown with flank concaving. Preview and OpenSCAD use the same piecewise smooth formula.
- Rotatable viewer, STL import/overlay and original exports retained.
- Physical-pendulum MOI measurement form on each fitting session; saves MOI about pivot and calculated MOI about centre of mass.
- Fitting comparison now carries recorded pivot MOI data.

## MOI procedure
1. Measure the finished bat mass and balance location from handle end.
2. Suspend it from a low-friction transverse pivot; record pivot location from the *same* handle datum.
3. Use small (<10°) oscillations, time 10 or more full cycles and repeat the measurement.
4. Record the time and pivot in the session MOI card. Compare pivot MOI only for the same pivot position and test method.

I_p = m g d (T / 2π)^2; I_com = I_p − m d², where d is pivot-to-COM distance and T = elapsed time / cycles.

## Geometry limitations
The default station depths are **design assumptions**, not scanned measurements. The tool models a blade blank and does not prove sweet-spot location, vibration characteristics, durability or CNC-ready process parameters. Confirm inputs before making cuts. STL visual alignment is not metrology-grade registration.

## Upgrade
Back up the existing `data/` folder and `.env`; overwrite source, preserve data, run `docker compose up -d --build`. External port remains 3001.
