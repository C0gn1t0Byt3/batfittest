// src/server.js
const http = require("http");
const app = require("./app");
const { env } = require("./config/env");

const server = http.createServer(app);

require('./config/db').ready.then(()=>{
  server.listen(env.PORT, () => console.log(`YKR BatFIT ready on port ${env.PORT}`));
}).catch(err=>{console.error('Database initialisation failed:',err);process.exit(1)});
