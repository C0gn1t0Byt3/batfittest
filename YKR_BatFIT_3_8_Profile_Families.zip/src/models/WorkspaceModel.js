const { db } = require('../config/db');
const run = (sql,params=[]) => new Promise((resolve,reject)=>db.run(sql,params,function(err){if(err) reject(err);else resolve(this.lastID)}));
const all = (sql,params=[]) => new Promise((resolve,reject)=>db.all(sql,params,(err,rows)=>err?reject(err):resolve(rows)));
const get = (sql,params=[]) => new Promise((resolve,reject)=>db.get(sql,params,(err,row)=>err?reject(err):resolve(row)));
module.exports={run,all,get};
