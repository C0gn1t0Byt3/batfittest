const express = require("express");
const router = express.Router();

router.get("/admin/login", (req, res) => {
  res.render("admin/login", { title: "Admin Login", error: null });
});

router.post("/admin/login", (req, res) => {
  const password = String(req.body.password || "");
  const expected = process.env.ADMIN_PASSWORD || "batfit123";
  if (password === expected) {
    req.session.isAdmin = true;
    return res.redirect("/workspace");
  }
  return res.status(401).render("admin/login", {
    title: "Admin Login", error: "Incorrect password"
  });
});

router.post("/admin/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/admin/login"));
});

module.exports = router;
