// v2.9 approximate station-based design exploration. Not a cutting plan.
const num=(v)=>Number(v);
function design(raw){
 const labels={mass_g:'Bat mass',balance_mm:'Balance point',length_mm:'Overall bat length',blade_length_mm:'Blade length',blade_width_mm:'Blade width',edge_mm:'Maximum edge',spine_mm:'Maximum depth',spine_peak_mm:'Spine peak height',density_g_cm3:'Estimated density'};
 const p={};for(const k of Object.keys(labels)){if(raw[k]===undefined||raw[k]===null||String(raw[k]).trim()==='')throw Error('Enter '+labels[k]+' under Reference measurements.');p[k]=num(raw[k]);if(!Number.isFinite(p[k]))throw Error('Invalid '+labels[k]);}
 if(p.mass_g<350||p.mass_g>2000)throw Error('Bat mass must be 350–2000 g');
 if(p.length_mm<500||p.length_mm>1100)throw Error('Overall length must be 500–1100 mm');
 if(p.blade_length_mm<250||p.blade_length_mm>=p.length_mm)throw Error('Blade length must be at least 250 mm and less than overall length');
 if(p.balance_mm<=0||p.balance_mm>=p.length_mm)throw Error('Balance point must be between the handle end and toe (less than overall length)');
 if(p.blade_width_mm<60||p.blade_width_mm>108)throw Error('Blade width must be 60–108 mm');
 if(p.edge_mm<5||p.edge_mm>40)throw Error('Maximum edge must be 5–40 mm');
 if(p.spine_mm<p.edge_mm||p.spine_mm>67)throw Error('Maximum depth must be at least edge thickness and no more than 67 mm');
 if(p.spine_peak_mm<0||p.spine_peak_mm>p.blade_length_mm)throw Error('Spine peak must lie between toe and shoulder');
 if(p.density_g_cm3<0.25||p.density_g_cm3>0.75)throw Error('Estimated willow density must be 0.25–0.75 g/cm³');
 const goal=String(raw.goal||'weight');
 if(!['weight','balance','profile','replicate'].includes(goal))throw Error('Choose a valid design objective');
 const target=Number(raw.target);if(!Number.isFinite(target))throw Error('Enter a target');
 const shape=Array.isArray(raw.stations)?raw.stations:[];
 if(shape.length!==5)throw Error('Enter five blade stations');
 const B=p.blade_length_mm,W=p.blade_width_mm,E=p.edge_mm,D=p.spine_mm,P=p.spine_peak_mm;
 const stations=shape.map((s,i)=>{for(const k of ['width','edge','depth'])if(s[k]===undefined||s[k]===null||String(s[k]).trim()==='')throw Error('Enter station '+(i+1)+' '+k);return {y:Math.round(B*[.1,.3,.5,.7,.9][i]),width:num(s.width),edge:num(s.edge),depth:num(s.depth)};});
 for(const s of stations){if(![s.width,s.edge,s.depth].every(Number.isFinite)||s.width<25||s.width>108||s.edge<3||s.edge>40||s.depth<s.edge||s.depth>67)throw Error('Station '+(stations.indexOf(s)+1)+': width 25–108 mm, edge 3–40 mm and centre depth between edge thickness and 67 mm.');}
 for(let i=1;i<stations.length;i++)if(Math.abs(stations[i].width-stations[i-1].width)>65)throw Error('Review abrupt width differences between stations');
 const desired=goal==='weight'?target:goal==='balance'?target:null;
 if(goal==='weight'&&(target<=0||target>p.mass_g))throw Error('Target mass must be between 0 and original mass');
 if(goal==='balance'&&(target<=0||target>=p.length_mm))throw Error('Balance target must lie on the bat');
 const maxShave=Math.min(12,Math.max(0,D-E));
 // Material removal at measured stations. Interpolate section dimensions and apply symmetrical back reduction.
 function simulate(shave,centre=P,half=140){
  const N=400,dy=B/N;let m=0,moment=0,second=0,vol=0;
  const interpolate=(y,key)=>{if(y<=stations[0].y)return stations[0][key];if(y>=stations[4].y)return stations[4][key];for(let i=1;i<5;i++){if(y<=stations[i].y){const a=stations[i-1],b=stations[i],t=(y-a.y)/(b.y-a.y);return a[key]+t*(b[key]-a[key]);}}return stations[4][key];};
  for(let i=0;i<N;i++){
   const y=(i+.5)*dy, w=interpolate(y,'width'),edge=interpolate(y,'edge'),depth=interpolate(y,'depth');
   const delta=Math.min(Math.max(0,depth-edge),shave*Math.max(0,1-Math.abs(y-centre)/half));
   const dv=.5*w*delta*dy/1000,dm=dv*p.density_g_cm3,x=p.length_mm-y;
   vol+=dv;m+=dm;moment+=dm*x;second+=dm/1000*(x/1000)**2;
  }
  const finalMass=p.mass_g-m,finalBalance=(p.mass_g*p.balance_mm-moment)/finalMass;
  return {shave_mm:+shave.toFixed(2),removed_mass_g:+m.toFixed(2),removed_volume_cm3:+vol.toFixed(2),final_mass_g:+finalMass.toFixed(2),final_balance_mm:+finalBalance.toFixed(2),balance_change_mm:+(finalBalance-p.balance_mm).toFixed(2),removed_handle_second_moment_kgm2:+second.toFixed(6),centre_mm:centre,half_length_mm:half};
 }
 let best=simulate(0),reason='';
 if(goal==='weight'||goal==='balance'){
  let gap=Infinity;
  for(let i=0;i<=240;i++){
   const item=simulate(maxShave*i/240);
   const diff=Math.abs((goal==='weight'?item.final_mass_g:item.final_balance_mm)-desired);
   if(diff<gap){gap=diff;best=item;}
  }
  reason=gap>(goal==='weight'?2:1)?'Requested target is not achievable with this limited spine-removal model. Revise the goal or measure more geometry.':'Estimated target reached within model precision.';
 }else if(goal==='profile'){
  const requested=Math.max(0,Math.min(maxShave,target));best=simulate(requested);reason='Exploratory spine reduction; no claim about sweet spot or rebound.';
 }else{reason='Replication: retain the measured reference geometry and mass distribution.';}
 const feasible=goal==='weight'?Math.abs(best.final_mass_g-target)<=2:goal==='balance'?Math.abs(best.final_balance_mm-target)<=1:true;
 const productionStations=stations.map(s=>({from_toe_mm:s.y,width_mm:s.width,edge_mm:s.edge,reference_centre_depth_mm:s.depth,proposed_centre_depth_mm:+(s.depth-Math.min(Math.max(0,s.depth-s.edge),best.shave_mm*Math.max(0,1-Math.abs(s.y-best.centre_mm)/best.half_length_mm))).toFixed(2)}));
 return {goal,target,baseline:{mass_g:p.mass_g,balance_mm:p.balance_mm,length_mm:p.length_mm,blade_length_mm:B,spine_peak_mm:P,density_g_cm3:p.density_g_cm3},stations,production_stations:productionStations,proposal:best,feasible,reason,assumptions:'Symmetrical triangular back crown, piecewise linear blade station geometry, uniform assumed density. Geometry changes are idealised.',next_action:feasible?'Review the profile visually and confirm remaining blade dimensions before shaping.':'Do not shape to this target; change the objective or collect a full profile/scan.'};
}
module.exports={design};
