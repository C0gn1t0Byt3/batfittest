// BatFIT 2.8 exploratory geometry calculation. NOT a performance/sweet-spot predictor.
// Blade back model: edge-thickness rectangular slab plus triangular spine section.
// Changes represent symmetric shaving of spine height, with a triangular longitudinal taper.
const finite=(v)=>typeof v==='number'&&Number.isFinite(v);
function calculate(p){
 const names=['mass_g','balance_mm','length_mm','blade_length_mm','blade_width_mm','edge_mm','spine_mm','spine_peak_mm','density_g_cm3','shave_mm','zone_half_mm'];
 for(const k of names)if(!finite(p[k]))throw Error('Enter a valid number for '+k);
 const {mass_g:m,balance_mm:com,length_mm:L,blade_length_mm:B,blade_width_mm:W,edge_mm:E,spine_mm:D,spine_peak_mm:P,density_g_cm3:rho,shave_mm:S,zone_half_mm:Z}=p;
 if(m<350||m>2000||L<500||L>1100||B<250||B>L||W<60||W>108||E<5||E>40||D<E||D>67||P<0||P>B||com<=0||com>=L||rho<0.25||rho>0.75||S<0||S>D-E||Z<20||Z>B)throw Error('Measurements or shaping inputs outside allowed range. Check length, depth and balance.');
 // Datum: handle end, so x = L - y, with y measured upward from the toe.
 // Approximate removed spine depth at each blade station (triangular longitudinal taper).
 const steps=300,dy=B/steps;let removedVolume=0,removedMass=0,removedMoment=0,removedI=0;
 for(let i=0;i<steps;i++){
  const y=(i+0.5)*dy;
  const taper=Math.max(0,1-Math.abs(y-P)/Z);
  const deltaD=S*taper;
  // Triangular transverse crown: changed cross-sectional area = W * deltaD / 2 (mm^2)
  const vol=W*deltaD*dy/2;const g=vol/1000*rho;
  const x=L-y;removedVolume+=vol/1000;removedMass+=g;removedMoment+=g*x;removedI+=(g/1000)*(x/1000)**2;
 }
 if(removedMass>=m)throw Error('Removed mass exceeds total bat mass.');
 const newMass=m-removedMass;
 const newBalance=(m*com-removedMoment)/newMass;
 // Not true swing inertia: only the change in second mass moment about handle-end datum.
 return {removed_volume_cm3:+removedVolume.toFixed(2),removed_mass_g:+removedMass.toFixed(2),estimated_mass_g:+newMass.toFixed(2),estimated_balance_mm:+newBalance.toFixed(2),balance_change_mm:+(newBalance-com).toFixed(2),first_mass_moment_before_kgm:+(m*com/1e6).toFixed(5),first_mass_moment_after_kgm:+(newMass*newBalance/1e6).toFixed(5),removed_second_mass_moment_kgm2:+removedI.toFixed(6),estimated_peak_depth_after_mm:+(D-S).toFixed(2),method:'Idealised symmetric triangular spine shaving. Constant estimated density. Mass/balance relative to actual weighed baseline; excludes handles, cleft density gradients and pressing effects.',warnings:['Geometry is an approximation, not a scan or a manufacturing cutting plan.','Mass and balance must be remeasured after shaping.','This model cannot predict sweet spot, rebound, structural integrity or full moment of inertia.']};
}
module.exports={calculate};
