// BatFIT 2.7: evidence-based trial decision with a finite test cycle.
// Impact mean is where the player contacts the ball, not measured sweet spot.
const has=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x));
const n=x=>has(x)?Number(x):null;
const goalOf=s=>{const x=String(s||'').toLowerCase();return /forgiv|consisten|control|miss/.test(x)?'control':/speed|power/.test(x)?'speed':/pickup|pick-up|lighter|weight/.test(x)?'pickup':/sweet|impact|toe/.test(x)?'impact':'balanced'};
const round=(x,d=1)=>x===null?null:Number(x.toFixed(d));
function decide({session,measurements,impacts,comparisons,stats}){
 const goal=goalOf(session.goal);
 const current={session_id:session.id,bat:session.bat_label||'Current bat',mass_g:measurements.mass_g??session.initial_mass_g??null,balance_mm:measurements.balance_mm??session.initial_balance_mm??null,length_mm:measurements.length_mm??session.initial_length_mm??null,blade_length_mm:measurements.blade_length_mm??null,spine_peak_from_toe_mm:measurements.spine_peak_from_toe_mm??null,spine_mm:measurements.spine_mm??null,edge_mm:measurements.edge_mm??null,swing_speed_mps:measurements.swing_speed_mps??null,impact_count:impacts.length,impact_spread_mm:stats.spread_mm,impact_mean_y_mm:stats.mean_y_mm,pickup:measurements.subjective_pickup??null};
 const all=[current,...comparisons].sort((a,b)=>a.session_id-b.session_id);
 const eligible=all.filter(x=>has(x.swing_speed_mps)&&has(x.impact_spread_mm)&&x.impact_count>=8);
 const speeds=eligible.map(x=>n(x.swing_speed_mps));const spreads=eligible.map(x=>n(x.impact_spread_mm));
 const norm=(v,lo,hi,reverse=false)=>hi===lo?0.5:reverse?(hi-v)/(hi-lo):(v-lo)/(hi-lo);
 const score=x=>{
  const s=norm(n(x.swing_speed_mps),Math.min(...speeds),Math.max(...speeds));
  const c=norm(n(x.impact_spread_mm),Math.min(...spreads),Math.max(...spreads),true);
  if(goal==='speed')return 0.8*s+0.2*c;
  if(goal==='control'||goal==='impact')return 0.2*s+0.8*c;
  if(goal==='pickup')return 0.4*s+0.4*c+0.2*(has(x.pickup)?(n(x.pickup)-1)/9:0.5);
  return 0.5*s+0.5*c;
 };
 const ranked=[...eligible].sort((a,b)=>score(b)-score(a)||a.session_id-b.session_id);
 const preferred=ranked[0]||all.find(x=>x.session_id===session.id)||all[0];
 const runnerUp=ranked[1]||null;
 const notices=[];
 if(eligible.length<2)notices.push('Compare at least two bats with speed and 8+ recorded impacts per bat.');
 if(has(preferred.balance_mm)&&has(preferred.length_mm)&&n(preferred.balance_mm)>=n(preferred.length_mm))notices.push('Balance point must be less than total bat length; remeasure.');
 else if(has(preferred.balance_mm)&&n(preferred.balance_mm)>600)notices.push('Confirm balance datum and measurement; unusually high reading.');
 if(has(preferred.blade_length_mm)&&has(preferred.impact_mean_y_mm)&&n(preferred.impact_mean_y_mm)>n(preferred.blade_length_mm))notices.push('Contact location exceeds recorded blade length; check coordinates.');
 let stage='collect',next='Record swing speed and at least 8 impacts for a second trial bat.';
 if(eligible.length>=2){
  // Stop when there is a credible measured winner. Additional trial is purposeful, not an automatic mass reduction.
  const speedDiff=n(preferred.swing_speed_mps)-n(runnerUp.swing_speed_mps);
  const spreadDiff=n(runnerUp.impact_spread_mm)-n(preferred.impact_spread_mm);
  const bothBetter=speedDiff>=0&&spreadDiff>=0&&(speedDiff>0||spreadDiff>0);
  const speedMargin=speedDiff>=Math.max(1.5,n(runnerUp.swing_speed_mps)*0.05);
  const spreadMargin=spreadDiff>=Math.max(5,n(runnerUp.impact_spread_mm)*0.10);
  if(eligible.length>=3&&bothBetter&&(speedMargin||spreadMargin)){
   stage='ready';next='Stop comparative trials. Review the preferred bat with the player, then save a custom design draft.';
  }else if(eligible.length>=4){
   stage='review';next='Stop adding bats. Review the top two trial results and player feedback; only retest if the difference would change your design choice.';
  }else{
   stage='confirm';next=`If a decision is still unclear, compare bat #${preferred.session_id} with #${runnerUp.session_id} using 10 deliveries per bat on the bowling machine. Record speed, impacts and preference.`;
  }
 }
 const impact=n(preferred.impact_mean_y_mm),spine=n(preferred.spine_peak_from_toe_mm),blade=n(preferred.blade_length_mm);
 const difference=spine!==null&&impact!==null?round(impact-spine):null;
 let profileDirection='Keep existing profile as the reference; do not move the spine solely from the impact map.';
 if(difference!==null){
  if(Math.abs(difference)<=35)profileDirection='Typical contact is close to the spine peak. Keep current profile as the starting design.';
  else profileDirection=`Typical contact is ${Math.abs(difference)} mm ${difference<0?'below':'above'} the spine peak. Compare hitting response there before shifting wood.`;
 }
 const profile={impact_mean_mm:round(impact),spine_peak_mm:round(spine),offset_mm:difference,blade_length_mm:round(blade),impact_spread_mm:round(n(preferred.impact_spread_mm)),direction:profileDirection,explanation:'Spine peak is a geometry feature, not a measured sweet spot. Impact spread measures contact grouping; it does not measure rebound performance.'};
 let options=[];
 if(has(preferred.mass_g)&&has(preferred.balance_mm)){
  options=[{name:'Reference design',mass_g:n(preferred.mass_g),balance_mm:n(preferred.balance_mm),description:'Match the best observed bat before changing geometry.'},
   {name:'Profile comparison',mass_g:n(preferred.mass_g),balance_mm:n(preferred.balance_mm),description:'Keep mass/balance near the reference; trial spine/profile distribution only if contact performance or player feedback warrants it.'}];
 }else options=[{name:'Measure the preferred bat',mass_g:null,balance_mm:null,description:'Record its mass and balance before specifying a custom design.'}];
 const status=stage==='ready'?'Design review ready':stage==='review'?'Fitter decision required':stage==='confirm'?'One confirmation trial':'More measurements needed';
 return {goal,reason:eligible.length?`Preferred measured bat for ${goal} fitting`:'Insufficient comparable tests',confidence:status,stage,total_sessions:all.length,eligible_sessions:eligible.length,
 session_summary:all.map(x=>({session_id:x.session_id,bat:x.bat,mass_g:x.mass_g,balance_mm:x.balance_mm,swing_speed_mps:x.swing_speed_mps,impact_count:x.impact_count,impact_spread_mm:x.impact_spread_mm,spine_peak_from_toe_mm:x.spine_peak_from_toe_mm,eligible:eligible.includes(x)})),
 preferred,design:{options,profile:profileDirection,profile_geometry:profile,contact_region:impact!==null?`${round(impact)} mm above toe (average contact)`:'Record impact positions',handle:'Keep existing handle unless the player reports a specific problem.',length:has(preferred.length_mm)?`${preferred.length_mm} mm`:'Measure overall length',status},
 one_next_test:next,warnings:notices,notes_used:!!String(session.notes||'').trim(),draft_target:{target_mass_g:n(preferred.mass_g),target_balance_mm:n(preferred.balance_mm),rationale:`Session #${preferred.session_id}; ${status}`}};
}
module.exports={decide,extractGoal:goalOf};
