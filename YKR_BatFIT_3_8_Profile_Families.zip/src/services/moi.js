// Small-angle physical-pendulum measurement, pivot about handle-side transverse axis.
function calculate({mass_g,balance_mm,pivot_mm=0,total_seconds,oscillations=10}){
 const m=Number(mass_g)/1000, d=(Number(balance_mm)-Number(pivot_mm))/1000;
 const n=Number(oscillations),seconds=Number(total_seconds);
 if(!(m>0.1&&m<3&&d>0.02&&d<1.1&&n>=5&&n<=100&&seconds>0))throw Error('Check mass, balance, pivot and timing');
 const period=seconds/n;
 if(!(period>=0.5&&period<=10))throw Error('Unreasonable period; time complete oscillations');
 const pivotMOI=m*9.80665*d*(period/(2*Math.PI))**2;
 const comMOI=pivotMOI-m*d*d;
 if(comMOI<=0)throw Error('Invalid physical-pendulum result. Check pivot, timing and balance datum');
 return {period_s:+period.toFixed(4),pivot_moi_kg_m2:+pivotMOI.toFixed(6),com_moi_kg_m2:+comMOI.toFixed(6),pivot_mm:Number(pivot_mm),mass_g:Number(mass_g),balance_mm:Number(balance_mm),oscillations:n,total_seconds:seconds};
}
module.exports={calculate};
