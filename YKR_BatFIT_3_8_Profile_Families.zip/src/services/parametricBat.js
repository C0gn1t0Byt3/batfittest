// YKR BatFIT v3.8 - profile-family continuous loft kernel.
// Geometry uses a continuous longitudinal envelope and transverse peaked spine.
const n=(v,d)=>v==null||v===''?d:Number(v);
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const PRESETS={
 mid:{peak:.50,carry:.58,toe:.20,upper:.20,concave:0},
 high:{peak:.70,carry:.55,toe:.18,upper:.16,concave:0},
 low:{peak:.36,carry:.55,toe:.25,upper:.18,concave:0},
 extra_low:{peak:.26,carry:.49,toe:.30,upper:.16,concave:0},
 full:{peak:.49,carry:.85,toe:.55,upper:.42,concave:0},
 full_spine:{peak:.46,carry:.9,toe:.35,upper:.36,concave:0},
 extended:{peak:.48,carry:.96,toe:.36,upper:.38,concave:1.5},
 duckbill:{peak:.36,carry:.57,toe:.32,upper:.12,concave:0},
 concave:{peak:.49,carry:.65,toe:.25,upper:.24,concave:4}
};
const LABELS={mid:'Mid',high:'High',low:'Low',extra_low:'Extra Low',full:'Full Profile',full_spine:'Full Spine',extended:'Extended Spine',duckbill:'Duckbill',concave:'Concave'};
const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t)};
function build(input={}){
 const family=String(input.profile_family||'mid');
 if(!PRESETS[family])throw Error('Unknown profile family');
 const preset=PRESETS[family];
 const p={profile_family:family,blade_length_mm:n(input.blade_length_mm,550),width_mm:n(input.width_mm,105),edge_mm:n(input.edge_mm,35),peak_depth_mm:n(input.peak_depth_mm,62),peak_y_mm:n(input.peak_y_mm,NaN),carry_pct:n(input.carry_pct,preset.carry*100),toe_fullness_pct:n(input.toe_fullness_pct,preset.toe*100),upper_fullness_pct:n(input.upper_fullness_pct,preset.upper*100),concave_mm:n(input.concave_mm,preset.concave),crown_exponent:n(input.crown_exponent,1.0),concave_position:n(input.concave_position,.72),density_g_cm3:n(input.density_g_cm3,.42),target_mass_g:n(input.target_mass_g,1050),name:input.name||'YKR CNC blade'};
 if(!Number.isFinite(p.peak_y_mm))p.peak_y_mm=p.blade_length_mm*preset.peak;
 const valid=(condition,message)=>{if(!condition)throw Error(message)};
 for(const [k,v] of Object.entries(p))if(typeof v==='number')valid(Number.isFinite(v),'Invalid '+k);
 valid(p.blade_length_mm>=300&&p.blade_length_mm<=700,'Blade length must be 300–700 mm');
 valid(p.width_mm>=60&&p.width_mm<=108,'Blade width must be 60–108 mm');
 valid(p.edge_mm>=8&&p.edge_mm<=45,'Edge thickness must be 8–45 mm');
 valid(p.peak_depth_mm>p.edge_mm+2&&p.peak_depth_mm<=67,'Maximum depth must exceed edge thickness by at least 2 mm and be ≤67 mm');
 valid(p.peak_y_mm>=25&&p.peak_y_mm<=p.blade_length_mm-25,'Peak must be at least 25 mm inside blade');
 valid(p.carry_pct>=20&&p.carry_pct<=100,'Spine carry must be 20–100%');
 valid(p.toe_fullness_pct>=0&&p.toe_fullness_pct<=95,'Toe fullness must be 0–95%');
 valid(p.upper_fullness_pct>=0&&p.upper_fullness_pct<=95,'Upper fullness must be 0–95%');
 valid(p.concave_mm>=0&&p.concave_mm<=12,'Concaving must be 0–12 mm');
 valid(p.concave_mm<=Math.max(0,p.edge_mm-8),'Concaving exceeds remaining flank thickness');
 valid(p.crown_exponent>=.45&&p.crown_exponent<=2.4,'Crown sharpness must be 0.45–2.4');
 valid(p.concave_position>=.55&&p.concave_position<=.90,'Concave position must be 0.55–0.90');
 valid(p.density_g_cm3>=.25&&p.density_g_cm3<=.75,'Willow density must be 0.25–0.75 g/cm³');
 valid(p.target_mass_g>=200&&p.target_mass_g<=1800,'Finished-bat target mass invalid');
 const L=p.blade_length_mm,W=p.width_mm,peak=p.peak_y_mm,extra=p.peak_depth_mm-p.edge_mm;
 // One smooth monotonic rise and fall around a single constrained peak.
 // Smoothstep guarantees zero longitudinal slope at the peak, and no spline ringing.
 function longitudinal(y){
   const left=y<=peak, t=left?y/peak:(L-y)/(L-peak);
   const end=(left?p.toe_fullness_pct:p.upper_fullness_pct)/100;
   const carry=p.carry_pct/100;
   const progress=Math.pow(smooth(t),.5+1.8*(1-carry));
   return end+(1-end)*progress;
 }
 function cross(x,y){
   const u=clamp(Math.abs(2*x/W),0,1);
   // No flat central plateau: derivative immediately descends away from the ridge.
   const crown=Math.pow(Math.max(0,1-u),.62*p.crown_exponent);
   const flankEnvelope=Math.pow(Math.max(0,1-((u-p.concave_position)/.20)**2),2)*Math.sin(Math.PI*u)**2;
   const pocket=p.concave_mm*flankEnvelope*Math.sin(Math.PI*y/L)**2;
   return Math.max(8,p.edge_mm+extra*longitudinal(y)*crown-pocket);
 }
 const ny=64,nx=40,verts=[],faces=[];
 const ix=(layer,i,j)=>layer*(ny+1)*(nx+1)+i*(nx+1)+j;
 for(let layer=0;layer<2;layer++)for(let i=0;i<=ny;i++)for(let j=0;j<=nx;j++){
   const y=L*i/ny,x=W*(j/nx-.5);verts.push([x,y,layer?cross(x,y):0]);
 }
 for(let i=0;i<ny;i++)for(let j=0;j<nx;j++){
  const a=ix(0,i,j),b=ix(0,i+1,j),c=ix(0,i+1,j+1),d=ix(0,i,j+1);
  faces.push([a,b,c],[a,c,d]);
  const A=ix(1,i,j),B=ix(1,i+1,j),C=ix(1,i+1,j+1),D=ix(1,i,j+1);
  faces.push([A,D,C],[A,C,B]);
 }
 for(let i=0;i<ny;i++)for(const j of [0,nx]){
  const a=ix(0,i,j),b=ix(0,i+1,j),c=ix(1,i+1,j),d=ix(1,i,j);
  if(j===0)faces.push([a,d,c],[a,c,b]);else faces.push([a,b,c],[a,c,d]);
 }
 for(let j=0;j<nx;j++)for(const i of [0,ny]){
  const a=ix(0,i,j),b=ix(0,i,j+1),c=ix(1,i,j+1),d=ix(1,i,j);
  if(i===0)faces.push([a,b,c],[a,c,d]);else faces.push([a,d,c],[a,c,b]);
 }
 let volume=0,firstMoment=0,secondMoment=0;
 const stations=[];
 for(let i=0;i<=ny;i++){
  const y=L*i/ny;let area=0;
  for(let j=0;j<nx;j++)area+=cross(W*((j+.5)/nx-.5),y)*W/nx;
  stations.push({y:+y.toFixed(3),width:W,centre_depth:+cross(0,y).toFixed(3),area_mm2:+area.toFixed(3)});
  if(i){const a0=stations[i-1].area_mm2,dy=L/ny,v=(a0+area)*dy/2,mid=y-dy/2;volume+=v;firstMoment+=v*mid;secondMoment+=v*mid*mid;}
 }
 const mass=volume/1000*p.density_g_cm3;
 return {params:p,preset:LABELS[family],stations,mesh:{vertices:verts,faces},estimated:{blade_volume_cm3:+(volume/1000).toFixed(2),blade_mass_g:+mass.toFixed(2),blade_com_from_toe_mm:+(firstMoment/volume).toFixed(2),blade_longitudinal_inertia_about_toe_kgm2:+(secondMoment*p.density_g_cm3/1e12).toFixed(6)},notes:'Blade-only uniform-density estimate; finished bat balance and MOI must not be inferred directly.'};
}
// Exports exactly the triangulated geometry used by the browser preview.
// Numeric CAD handoff, not a feature-tree STEP solid or machine-specific toolpath.
function openscad(result){const v=result.mesh.vertices,f=result.mesh.faces;
 return '// YKR BatFIT v3.8 mesh-backed OpenSCAD; profile family '+result.params.profile_family+' (mm)\n'+
 'polyhedron(points='+JSON.stringify(v)+',faces='+JSON.stringify(f)+',convexity=10);\n';
}
module.exports={build,openscad,PRESETS,LABELS};
