// src/app.js
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const fitHistoryRoutes = require("./routes/fitHistoryRoutes");
const fitRoutes = require("./routes/fitRoutes");
const adminBatsRoutes = require("./routes/adminBatsRoutes");
const session = require("express-session");
const adminAuthRoutes = require("./routes/adminAuthRoutes");

const { env } = require("./config/env");
const { limiter } = require("./middleware/rateLimit");
const { notFoundHandler, errorHandler } = require("./middleware/errorHandler");

const routes = require("./routes");

// Ensure DB is initialised (schema + seed)
require("./config/db");

const app = express();
app.get('/healthz',(_req,res)=>res.status(200).send('ok'));

// Security headers
app.use(
  helmet({
    contentSecurityPolicy: false, // keep simple for Bootstrap/CDN in dev
  })
);

// Logging
app.use(morgan(env.NODE_ENV === "production" ? "combined" : "dev"));

// Basic anti-scrape throttling
app.use(limiter);

// Body parsers
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Cookies (future auth/session)
app.use(cookieParser());

app.use(session({
  secret: env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE === "true" // set when accessing via HTTPS
  }
}));



// Views
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.set("compileDebug", env.NODE_ENV !== "production");
app.set("debug", env.NODE_ENV !== "production");

// Static assets
app.use(express.static(path.join(__dirname, "..", "public")));

// Local-development deployment: application remains protected by login.
// Restrict Docker port exposure to trusted local networks only.

// Routes
// All fitting data is private: require login for every application route.
// Static CSS, JS and logo files remain accessible to render the login screen.
app.use((req,res,next)=>{
 if(req.path==='/admin/login') return next();
 if(req.session && req.session.isAdmin) return next();
 if(req.path.startsWith('/api/')) return res.sendStatus(401);
 return res.redirect('/admin/login');
});
app.use("/", require("./routes/workspaceRoutes"));
app.use("/", routes);
app.use("/", fitHistoryRoutes);
app.use("/fit", fitRoutes);
app.use("/", adminBatsRoutes);
app.use("/", adminAuthRoutes);

// Errors
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
