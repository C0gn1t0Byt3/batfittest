-- src/db/schema.sql
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS tenants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Start with a single tenant (future SaaS foundation)
INSERT OR IGNORE INTO tenants (id, name) VALUES (1, 'Default Tenant');

CREATE TABLE IF NOT EXISTS bats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL DEFAULT 1,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  size_label TEXT NOT NULL,          -- e.g., "SH", "Harrow", "6"
  weight_g INTEGER NOT NULL,         -- total mass
  pickup_rating INTEGER NOT NULL,    -- 1-10 subjective
  sweet_spot TEXT NOT NULL,          -- low/mid/high
  profile TEXT NOT NULL,             -- balanced/toe_heavy/etc
  handle_shape TEXT NOT NULL,        -- oval/round
  handle_length TEXT NOT NULL,       -- short/standard/long
  bow TEXT NOT NULL,                 -- low/mid/high
  notes TEXT,
  image_url TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id)
);

CREATE TABLE IF NOT EXISTS fits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,

  height_cm INTEGER,
  weight_kg INTEGER,
  hand_size_cm REAL,
  floor_to_wrist_cm REAL,
  shot_type TEXT,
  conditions TEXT,
  footwork TEXT,
  batter_style TEXT,
  max_distance_m INTEGER,
  experience TEXT,
  brand_filter TEXT,

  input_json TEXT NOT NULL,
  shot_map_json TEXT,
  result_json TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_bats_unique
ON bats (tenant_id, brand, model, size_label);

-- BatFIT 2.0: explicitly separate measured observations from imported catalogue data.
CREATE TABLE IF NOT EXISTS players (
 id INTEGER PRIMARY KEY AUTOINCREMENT, display_name TEXT NOT NULL, height_cm REAL, wrist_to_floor_cm REAL, hand_size_cm REAL, notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS player_bats (
 id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL REFERENCES players(id), label TEXT NOT NULL, bat_type TEXT NOT NULL DEFAULT 'existing', mass_g REAL, balance_mm REAL, balance_datum TEXT NOT NULL DEFAULT 'handle_end', length_mm REAL, notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS fitting_sessions_v2 (
 id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL REFERENCES players(id), bat_id INTEGER REFERENCES player_bats(id), status TEXT NOT NULL DEFAULT 'baseline', goal TEXT, notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS measurement_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id), bat_id INTEGER REFERENCES player_bats(id), measurement_type TEXT NOT NULL, value REAL, unit TEXT, method TEXT NOT NULL DEFAULT 'manual', source TEXT NOT NULL DEFAULT 'measured', notes TEXT, recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_fitv2_player ON fitting_sessions_v2(player_id);
CREATE INDEX IF NOT EXISTS idx_measure_session ON measurement_events(session_id);

-- BatFIT 2.2: individual measured ball contacts, no synthetic catalogue values.
CREATE TABLE IF NOT EXISTS impact_points (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),
 x_mm REAL NOT NULL, -- face centreline: left negative, right positive, facing the blade
 y_mm REAL NOT NULL, -- from bottom of toe upward
 shot_type TEXT NOT NULL DEFAULT 'unspecified',
 recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_impacts_session ON impact_points(session_id);

-- BatFIT 2.3: analysis provenance and manually approved candidate targets.
CREATE TABLE IF NOT EXISTS agent_runs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),source TEXT NOT NULL,input_json TEXT NOT NULL,result_json TEXT NOT NULL,created_at TEXT DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS design_candidates (
 id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),target_mass_g REAL,target_balance_mm REAL,rationale TEXT,status TEXT NOT NULL DEFAULT 'draft',created_at TEXT DEFAULT (datetime('now')));

-- BatFIT 2.6 custom trial specifications (separate from prior draft target records).
CREATE TABLE IF NOT EXISTS custom_bat_specs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),
 reference_session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),
 target_mass_g REAL NOT NULL, target_balance_mm REAL NOT NULL,target_length_mm REAL,
 profile_direction TEXT,handle_direction TEXT,contact_region TEXT,notes TEXT,
 status TEXT NOT NULL DEFAULT 'draft',created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_custom_specs_session ON custom_bat_specs(session_id);

-- BatFIT 2.8 parametric geometry experiments. Not approved manufacturing instructions.
CREATE TABLE IF NOT EXISTS geometry_scenarios (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 session_id INTEGER NOT NULL REFERENCES fitting_sessions_v2(id),
 name TEXT NOT NULL,
 inputs_json TEXT NOT NULL,
 results_json TEXT NOT NULL,
 created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_geometry_session ON geometry_scenarios(session_id);
