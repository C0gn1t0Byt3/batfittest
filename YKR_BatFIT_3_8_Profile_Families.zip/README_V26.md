# YKR BatFIT 2.6 — custom bat trial design

## What's new
- All recorded fitting sessions appear in the analysis; trials without both speed and at least 8 impacts remain visible but are labelled **More data needed** instead of being silently omitted.
- Compact results: one preferred trial, two trial design options, blade/handle direction, one bowling-machine test.
- Contact position is taken from the *selected* trial, not automatically from the session currently open.
- Custom bat design drafts have editable mass, balance, length, profile, handle, contact region and maker notes. Drafts save to a separate `custom_bat_specs` table.
- The first option reproduces the measured reference; a second 2% lighter *experimental* option is displayed but is not a validated optimal weight. Do not manufacture from an unverified result.
- Gemini can add a one-sentence note but cannot change mass or balance calculations.

## Installation
Back up `data/` and `.env`. Replace application files, **do not overwrite data or .env**. Run `docker compose up -d --build`, then open http://localhost:3001.
Existing database tables are preserved. New table is created at startup.

## Fitting use
Use a bowling machine, record the setting, ball type and shot task, and alternate the trial bats in 10-ball blocks. Keep a session for each bat. Enter mass/balance/speed, map contacts, and select **Analyse fitting**. Custom bat drafts are editable. The impact centroid is NOT an experimentally verified sweet spot, and mass first moment is NOT moment of inertia.

## Checks
JS syntax checks performed and a three-trial decision-engine smoke test completed. Docker and end-to-end browser validation still required.
