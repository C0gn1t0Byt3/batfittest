# YKR BatFIT 2.7 – Fitting completion and blade geometry

## Changes
- The test cycle has a stopping rule. With three eligible trials, a bat that beats the runner-up on both speed and impact spread, with a meaningful difference on at least one, moves to **Design review ready**. After four eligible trials, it switches to **Fitter decision required** instead of looping indefinitely.
- Removed the automatic 2% mass reduction. A design no longer becomes progressively lighter just because another session is added.
- New assessment measurements: **blade length (toe to shoulder)** and **spine peak height (toe to maximum spine depth)**. These are optional and stored in existing `measurement_events` so no database migration is needed.
- The design recommendation now reports average contact position alongside measured spine peak, with a clear indication of their separation. This is *not* the true sweet spot or a rebound test.
- Alternative design is a **profile comparison** retaining reference mass and balance, not automatically making a lighter bat.
- Cleaner result language, one next action, and all recorded sessions displayed.

## How to use
1. For each trial, save bat mass, balance and swing speed, then map impacts.
2. If available, additionally measure blade length and the distance from toe to **peak spine depth**.
3. Click **Analyse fitting**. Review preferred trial, profile comparison and either the next measurement, one confirmation test, or the finish-fitting instruction.
4. Save the editable custom specification for bat-maker review.

## Important engineering points
- Average impact location is player contact tendency; it cannot identify the mechanical sweet spot on its own.
- Impact spread measures strike dispersion and should not be mistaken for size of the high-rebound region.
- Spine peak location and size influence geometry and mass distribution, but profile changes cannot be justified from the strike map alone. Face response/rebound observations and minimum remaining wood matter.
- First mass moment does not measure swing moment of inertia. Matching total mass and balance does not guarantee identical inertia or bat feel.
- The stop criteria are practical heuristics for prototyping, not statistically validated performance claims.

## Install
Back up existing `data/` and `.env`, extract the release over your BatFIT source without replacing these two, then `docker compose up -d --build`. Default local URL `http://localhost:3001`.
